const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');

const PORT = process.env.PORT || 8080;
const GAME = path.join(__dirname, 'زندگی_من_نسخه_۱۸.html');
const rooms = new Map();
const names = new Set();

function code(){
  const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let c='';
  do { c=''; for(let i=0;i<5;i++) c+=chars[Math.floor(Math.random()*chars.length)]; } while(rooms.has(c));
  return c;
}
function cleanName(v){ return String(v||'بازیکن').trim().slice(0,18).replace(/[<>]/g,'') || 'بازیکن'; }
function send(ws,obj){ if(ws.readyState===WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
function roomPlayers(room){
  const out={};
  for(const [id,p] of room.players) out[id]={x:p.x,y:p.y,page:p.page,name:p.name};
  return out;
}
function broadcast(room,obj){ for(const p of room.players.values()) send(p.ws,obj); }
function leave(ws){
  const room=ws.room && rooms.get(ws.room);
  if(!room)return;
  room.players.delete(ws.id);
  if(room.players.size===0) rooms.delete(ws.room);
  else broadcast(room,{type:'state',players:roomPlayers(room)});
  ws.room=null;
}

const server=http.createServer((req,res)=>{
  if(req.url==='/' || req.url==='/زندگی_من_نسخه_۱۸.html'){
    fs.createReadStream(GAME).pipe(res);
  } else { res.writeHead(404); res.end('Not found'); }
});
const wss=new WebSocket.Server({server});

wss.on('connection',(ws)=>{
  ws.id=Math.random().toString(36).slice(2,10);
  ws.room=null;
  ws.lastChat=0;
  ws.on('message',(raw)=>{
    let m; try{m=JSON.parse(raw.toString())}catch{return}
    if(!m || typeof m.type!=='string') return;
    if(m.type==='create' || m.type==='join'){
      leave(ws);
      const roomCode=m.type==='create'?code():String(m.room||'').toUpperCase();
      if(!/^[A-Z0-9]{5}$/.test(roomCode)) return send(ws,{type:'chat',name:'سیستم',text:'❌ کد اتاق نامعتبر است'});
      if(m.type==='join' && !rooms.has(roomCode)) return send(ws,{type:'chat',name:'سیستم',text:'❌ این اتاق پیدا نشد'});
      let room=rooms.get(roomCode);
      if(!room){room={players:new Map()};rooms.set(roomCode,room)}
      if(room.players.size>=20) return send(ws,{type:'chat',name:'سیستم',text:'❌ ظرفیت اتاق پر است'});
      const p={ws,id:ws.id,name:cleanName(m.name),x:Number(m.x)||360,y:Number(m.y)||275,page:m.page==='nextStreet'?'nextStreet':'main'};
      ws.room=roomCode; room.players.set(ws.id,p);
      send(ws,{type:'room',room:roomCode,players:roomPlayers(room)});
      broadcast(room,{type:'chat',name:'سیستم',text:p.name+' وارد اتاق شد'});
      broadcast(room,{type:'state',players:roomPlayers(room)});
      return;
    }
    const room=ws.room && rooms.get(ws.room); if(!room)return;
    const p=room.players.get(ws.id); if(!p)return;
    if(m.type==='state'){
      p.x=Math.max(20,Math.min(700,Number(m.x)||p.x));
      p.y=Math.max(20,Math.min(540,Number(m.y)||p.y));
      p.page=m.page==='nextStreet'?'nextStreet':'main';
      broadcast(room,{type:'state',players:roomPlayers(room)});
    } else if(m.type==='chat'){
      const now=Date.now(); if(now-p.lastChat<500)return; p.lastChat=now;
      const text=String(m.text||'').trim().slice(0,80); if(!text)return;
      broadcast(room,{type:'chat',name:p.name,text});
    }
  });
  ws.on('close',()=>leave(ws));
});
server.listen(PORT,()=>console.log(`زندگی من آنلاین روی http://localhost:${PORT}`));
